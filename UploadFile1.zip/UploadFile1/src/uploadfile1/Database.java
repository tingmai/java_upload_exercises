/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uploadfile1;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author htoinanbrang
 */
public class Database {
     public Connection getConnected(){
        Connection conn=null;
        try{
            Class.forName("org.sqlite.JDBC");
           conn = DriverManager.getConnection("jdbc:sqlite:mydb1.db");
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
        return conn;
    }

    com.sun.jdi.connect.spi.Connection getConnection() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
